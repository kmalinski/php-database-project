<?php
namespace frontend\models;

use yii\base\model;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

class OdpForm extends Model {
    public $odp;

public function rules() {
    return [
        [['odp'], 'required']
    ];
}
}