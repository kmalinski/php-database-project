<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "zestawdodaj".
 *
 *
 * @property string $username
 * @property string $nazwa
 * @property string $zestaw
 */
class Zestawdodaj extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'zestawdodaj';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['username', 'nazwa', 'zestaw'], 'required'],
            [['id'], 'integer'],
            [['zestaw'], 'string'],
            [['username', 'nazwa'], 'string', 'max' => 200],
            [['id'], 'unique'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'username' => 'Username',
            'nazwa' => 'Nazwa',
            'zestaw' => 'Zestaw',
        ];
    }
}
