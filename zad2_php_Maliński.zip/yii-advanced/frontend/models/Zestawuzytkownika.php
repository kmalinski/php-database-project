<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "zestawuzytkownika".
 *
 * @property int $id
 * @property int $konto_id
 * @property int $jezyk1_id
 * @property int $jezyk2_id
 * @property string $nazwa
 * @property string $zestaw
 * @property string $data_dodania
 *
 * @property Jezyk $jezyk1
 * @property Jezyk $jezyk2
 * @property Konto $konto
 */
class Zestawuzytkownika extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'zestawuzytkownika';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['konto_id', 'jezyk1_id', 'jezyk2_id', 'nazwa', 'zestaw', 'data_dodania'], 'required'],
            [['konto_id', 'jezyk1_id', 'jezyk2_id'], 'integer'],
            [['zestaw'], 'string'],
            [['data_dodania'], 'safe'],
            [['nazwa'], 'string', 'max' => 100],
            [['jezyk1_id'], 'exist', 'skipOnError' => true, 'targetClass' => Jezyk::className(), 'targetAttribute' => ['jezyk1_id' => 'id']],
            [['jezyk2_id'], 'exist', 'skipOnError' => true, 'targetClass' => Jezyk::className(), 'targetAttribute' => ['jezyk2_id' => 'id']],
            [['konto_id'], 'exist', 'skipOnError' => true, 'targetClass' => Konto::className(), 'targetAttribute' => ['konto_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'konto_id' => 'Konto ID',
            'jezyk1_id' => 'Jezyk1 ID',
            'jezyk2_id' => 'Jezyk2 ID',
            'nazwa' => 'Nazwa',
            'zestaw' => 'Zestaw',
            'data_dodania' => 'Data Dodania',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getJezyk1()
    {
        return $this->hasOne(Jezyk::className(), ['id' => 'jezyk1_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getJezyk2()
    {
        return $this->hasOne(Jezyk::className(), ['id' => 'jezyk2_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getKonto()
    {
        return $this->hasOne(Konto::className(), ['id' => 'konto_id']);
    }
}
