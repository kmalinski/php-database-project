<?php
namespace frontend\models;

use yii\base\Model;
use frontend\models\zestawdodaj;


class dodajZestaw extends Model
{

    public $nazwa;
    public $zestaw;



    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            ['nazwa', 'trim'],
            ['nazwa', 'required'],
            ['zestaw', 'required'],
            ['nazwa', 'string', 'min' => 2, 'max' => 255],

        ];
    }


    public function dodaj()
    {
        if (!$this->validate()) {
            return null;
        }

        $zestawdodaj = new Zestawdodaj();
        $zestawdodaj->konto_id = \Yii::$app->user->id;
        $zestawdodaj->nazwa = $this->nazwa;
        $zestawdodaj->zestaw = $this->zestaw;


        return $zestawdodaj->save() ? $zestawdodaj : null;
    }
}
