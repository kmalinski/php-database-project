<?php
namespace frontend\models;

use yii\base\model;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

class OdppForm extends Model {
    public $odpp;

    public function rules() {
        return [
            [['odpp'], 'required']
        ];
    }
}