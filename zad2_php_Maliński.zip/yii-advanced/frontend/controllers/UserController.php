<?php

namespace  app\controllers;

use yii\web\Controller;
use app\models\User;

class serController extends Controller {
    public function actionIndex() {
        echo "dziala test 123";
    }
}
?>