<?php

/* @var $this yii\web\View */
use yii\helpers\Html;

$this->title = 'Animals';
?>
<div class="jumbotron">
    <h1>Animals</h1>
    <p align="center"> <h2>Wybor podkategorii:</h2></p>
</div>

<div class="row">

    <div align="center">
        <p><h1>Fish</h1></p>
        <a href="http://localhost/yii-advanced/frontend/web/index.php?r=site/fish">
            <img src="images/fish.jpg" alt="fish">
        </a>
    </div>
    <div align="center">
        <p><h1>Birds</h1></p>
        <a href="http://localhost/yii-advanced/frontend/web/index.php?r=site/birds">
            <img src="images/bird.jpg" alt="bird">
        </a>
    </div>

    <div align="center">
        <p><h1>Farm Animals</h1></p>
        <a href="http://localhost/yii-advanced/frontend/web/index.php?r=site/farm">
            <img src="images/cow.jpg" alt="farm animals">
        </a>
    </div>
</div>