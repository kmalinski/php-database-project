<?php
use yii\helpers\Html;
use yii\db\QueryBuilder;
use yii\db\Query;

$wynik = $_SESSION['odp'];
$j=  $_SESSION['blad'];
$RanEn = $_SESSION['RanEn'];
$RanPl = $_SESSION['RanPl'];
$lan = $_GET['lan'];
//print_r($j);
$cunt = 0;
$pytanie = $_SESSION['pytanie'];
$odp = $_SESSION['answer'];
$zestaw = $_GET['zestaw'];
$p = $_SESSION['proby'];
for($i = 0; $i<count($wynik); $i++){
    if($wynik[$i] == 1) {
        $cunt++;
    }
}

$wyn = $cunt/$p;
$wyn2 = $wyn * 10;
$wyn2 = $wyn2.''.'%';
if(!Yii::$app->user->isGuest){

    echo Html::tag('h2', 'Wynik zostal zapisany');



    Yii::$app->db->createCommand()
        ->insert('wynik', [
            'konto_id' => Yii::$app->user->id,
            'zestaw_id' => $zestaw,
            'wynik' => $wyn,
        ])->execute();
}

?>

<div class="jumbotron">
    <h1>Twoj wynik to:</h1>
    <h2><?php echo $wyn2 ?></h2>
    <a class="btn btn-lg btn-success" href="http://localhost/yii-advanced/frontend/web/index.php">OK</a>
</div>








<?php  session_unset();   ?>
