<?php $this->title = 'Hello World'; ?>
<div class="site-about">
    <h1>Hello World</h1>
    <p>
        This is the hello page.
    </p>
</div>