<?php

$zestaw1 = 11;
$zestaw2 = 12;
/* @var $this yii\web\View */
use yii\helpers\Html;

$this->title = 'Meat';
?>
<div class="jumbotron">
    <h1>Dostepne zestawy:</h1>
</div>

<div class="row">

    <div align="center">
        <p><a class="btn btn-lg btn-default" href="http://localhost/yii-advanced/frontend/web/index.php?r=site/wybor&zestaw=<?php echo $zestaw1 ?>">Zestaw 1 &raquo;</a></p>
    </div>


    <div align="center">
        <p><a class="btn btn-lg btn-default" href="http://localhost/yii-advanced/frontend/web/index.php?r=site/wybor&zestaw=<?php echo $zestaw2 ?>">Zestaw 2 &raquo;</a></p>
    </div>

</div>
