<?php

$this->title = 'alg1';

$En = $_SESSION['finEn'];
$Pl = $_SESSION['finPl'];
$i = $_SESSION['counter'];
$RanEn = $_SESSION['RanEn'];
$RanPl = $_SESSION['RanPl'];
$lan = $_GET['lan'];
$answer = $_SESSION['odp'];

    if($lan == 'eng') {
    }
    ?>

<div class="jumbotron">
    <h1>Nauka</h1>
</div>

    <div>
        <p><a><?php echo $RanEn[$i];  $i++;?></a></p>
    </div>

