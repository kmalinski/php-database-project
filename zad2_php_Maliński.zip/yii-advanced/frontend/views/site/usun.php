<?php

use yii\db\QueryBuilder;
use yii\db\Query;

$id = $_GET['zestaw'];

$sql = (new \yii\db\Query())
    ->createCommand()
    ->delete('zestawdodaj', 'id=' . '' . $id)
    ->execute();
?>

<div class="jumbotron">
    <h1>Zestaw został usunięty</h1>

    <a class="btn btn-lg btn-success" href="http://localhost/yii-advanced/frontend/web/index.php?r=site/twojezestawy">Powrót do zestawów</a>
</div>
