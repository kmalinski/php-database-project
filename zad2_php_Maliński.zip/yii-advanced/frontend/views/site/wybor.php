<?php

$zestaw = $_GET['zestaw'];
$_SESSION['test'] = 'test';

/* @var $this yii\web\View */

use yii\helpers\Html;

if (isset($_GET['wlasny'])) {


}
$this->title = 'Wybor trybu';
?>

<div class="jumbotron">
    <h1>Wybor trybu</h1>
</div>

<div class="grid-view">
    <?php if (isset($_GET['wlasny'])) {
        echo Html::tag('h1', 'Tryb nauki');
        echo Html::a('Nauka', 'http://localhost/yii-advanced/frontend/web/index.php?r=site/nauka&zestaw=' . '' . $zestaw . '' . '&wlasny=true', ['class' => 'btn, btn-lg btn-default']);
        echo Html::tag('h1', 'Tryb sprawdzania wiedzy');
        echo Html::a('Wiedza', 'http://localhost/yii-advanced/frontend/web/index.php?r=site/nauka&zestaw=' . '' . $zestaw . '' . '&wlasny=true', ['class' => 'btn, btn-lg btn-default']);

    } else {
        echo Html::tag('h1', 'Tryb nauki');
        echo Html::a('Nauka', 'http://localhost/yii-advanced/frontend/web/index.php?r=site/nauka&zestaw=' . '' . $zestaw, ['class' => 'btn, btn-lg btn-default']);
        echo Html::tag('h1', 'Tryb sprawdzania wiedzy');
        echo Html::a('Wiedza', 'http://localhost/yii-advanced/frontend/web/index.php?r=site/nauka&zestaw=' . '' . $zestaw, ['class' => 'btn, btn-lg btn-default']);
    } ?>
</div>