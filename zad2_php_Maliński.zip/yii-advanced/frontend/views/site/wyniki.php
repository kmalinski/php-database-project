<!DOCTYPE html>
<html>
<head>
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        th,td {
            padding: 15px;
        }
    </style>
    <div class="jumbotron">
        <h1>Twoje Wyniki</h1>
    </div>
</head>
<body>
<?php
use yii\helpers\Html;
if(!Yii::$app->user->isGuest) {

    $id = \Yii::$app->user->id;
    $this->title='Twoje wyniki';
    $space = ':';

    $zestaw = (new \yii\db\Query())
        ->select(['wynik', 'data_wyniku', 'zestaw_id'])
        ->from('wynik')
        ->where(['konto_id' => $id])
        ->orderBy([
                'zestaw_id' => SORT_DESC,
            'data_wyniku' => SORT_ASC,
            ])
        ->all();
    if ($zestaw == NULL) {
        echo Html::tag('h1', 'Nie masz jeszcze zadnych wynikow', ['class' => 'jumbotron']);
        echo Html::a('OK', 'http://localhost/yii-advanced/frontend/web/index.php?', ['class' => 'btn, btn-lg btn-success', 'align' => 'center']);
    } else {

?>
<div align="center">
    <table>
        <tr>
            <th>Nazwa zestawu </th>
            <th> Wynik</th>
            <th>Data</th>
        </tr>
        <?php
        for ($i = 0; $i < count($zestaw); $i++) {
            $tmp = $zestaw[$i];
            $wyn = $tmp['wynik'] * 100;
            $wyn = $wyn . '' . '%';
            $zestawy = (new \yii\db\Query())
                ->select('nazwa')
                ->from('zestaw')
                ->where(['id' => $tmp['zestaw_id']])
                ->all();
            $nazwa = $zestawy[0];

            echo Html::tag('tr');
            echo Html::tag('td', $nazwa['nazwa']);
            echo Html::tag('td', $wyn);
            echo Html::tag('td', $tmp['data_wyniku']);

            echo Html::tag('/tr');


        }
        ?>
    </table>
</div>

        <?php

    }
}
else {
    echo Html::tag('h1', 'Musisz sie zalogowac aby miec dostep do wynikow', ['class' => 'jumbotron']);
    echo Html::a('OK','http://localhost/yii-advanced/frontend/web/index.php?', ['class' => 'btn, btn-lg btn-success','align'=>'center'] );
}

?>
</body>
</html>
