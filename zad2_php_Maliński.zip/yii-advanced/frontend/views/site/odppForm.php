<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$i = $_SESSION['counter'];
$En = $_SESSION['finEn'];
$Pl = $_SESSION['finPl'];
$wynik = $_SESSION['odp'];
$blad= $_SESSION['blad'];
$RanEn = $_SESSION['RanEn'];
$RanPl = $_SESSION['RanPl'];
$lan = $_GET['lan'];
$answer = $_SESSION['answer'];
$test = 'dziala';
$p = $_SESSION['cunt'];
$zestaw = $_GET['zestaw'];
//echo $i;
//echo '<br>';
//echo count($RanEn);
//print_r($blad);

if ($lan == 'eng') {
    if ($i != count($RanEn)) {
        $form = ActiveForm::begin(); ?>
        <?= Html::tag('h1', $RanEn[$i], ['class' => 'jumbotron']); ?>
        <?= $form->field($model, 'odpp'); ?>
        <?= Html::submitButton('Submit', ['class' => 'btn btn-success']); ?>

        <?php ActiveForm::end(); ?>
        <?php
        $tmp = $_SESSION['pytanie'];
        $tmp[$_SESSION['proby']] = $RanEn[$i];
        $_SESSION['pytanie'] = $tmp;
    }


    if (isset($_POST["OdppForm"])) {
        $te = $_POST["OdppForm"];
        //print_r($te);
        $tes = array_rand($te, 1);
        //echo $te[$tes];


        for ($j = 0; $j < count($RanEn); $j++) {
            if ($i == 0) {
                if ($RanEn[0] == $En[$j]) {
                    $x = $j;

                }
            } elseif ($RanEn[$i - 1] == $En[$j]) {
                $x = $j;
            }
        }

        if ($te[$tes] == $Pl[$x]) {

           // echo 'ok';
            $answer[$i-1] = $te[$tes];
            $_SESSION['answer'] = $answer;
            $wynik[$_SESSION['wynCounter']] = 1;
            $_SESSION['wynCounter']++;
            $_SESSION['odp'] = $wynik;
            $i++;
            $_SESSION['counter'] = $i;
            $_SESSION['proby']++;
        } else {
            $answer[$i-1] = $te[$tes];
            $_SESSION['answer'] = $answer;
            $blad[$p] = $RanEn[$i-1];
            $p++;
            $_SESSION['cunt'] = $p;
            $_SESSION['blad'] = $blad;
            $i++;
            $_SESSION['counter'] = $i;
            $_SESSION['proby']++;
            //echo 'nie ok';
        }
    } else {

        $i++;
        $_SESSION['counter'] = $i;
    }
}


elseif ($lan == 'pl') {
    if ($i != count($RanPl)) {
        $form = ActiveForm::begin(); ?>
        <?= Html::tag('h1', $RanPl[$i], ['class' => 'jumbotron']); ?>
        <?= $form->field($model, 'odpp'); ?>
        <?= Html::submitButton('Submit', ['class' => 'btn btn-success']); ?>

        <?php ActiveForm::end(); ?>

        <?php
        $tmp = $_SESSION['pytanie'];
        $tmp[$_SESSION['proby']] = $RanPl[$i];
        $_SESSION['pytanie'] = $tmp;
    }
    //$_SESSION['counter'] = $i;
    if (isset($_POST["OdppForm"])) {
        $te = $_POST["OdppForm"];
       //print_r($te);
        $tes = array_rand($te, 1);
       // echo $te[$tes];


        for ($j = 0; $j < count($RanPl); $j++) {
            if ($i == 0) {
                if ($RanPl[0] == $Pl[$j]) {
                    $x = $j;

                }
            } elseif ($RanPl[$i - 1] == $Pl[$j]) {
                $x = $j;
            }
        }
        if (isset($te)) {
            if ($te[$tes] == $En[$x]) {

                //echo 'ok';
                $answer[$i-1] = $te[$tes];
                $_SESSION['answer'] = $answer;
                $wynik[$_SESSION['wynCounter']] = 1;
                $_SESSION['wynCounter']++;
                $_SESSION['odp'] = $wynik;
                $i++;
                $_SESSION['counter'] = $i;
                $_SESSION['proby']++;
            } else {
                $answer[$i-1] = $te[$tes];
                $_SESSION['answer'] = $answer;
                $i++;
                $_SESSION['counter'] = $i;
                $_SESSION['proby']++;
                //echo 'nie ok';
            }
        }
    } else {

        $i++;
        $_SESSION['counter'] = $i;
    }
}
if($i == count($RanEn)+1) {
    if($lan=='pl') {
        $RanPl = $blad;
        $_SESSION['RanPl'] = $RanPl;
        $_SESSION['counter'] = 0;
        $tmp[0] = NULL;
        $blad = $tmp;
        $_SESSION['blad'] = $blad;
        $_SESSION['cunt'] = 0;
        header('Location: http://localhost/yii-advanced/frontend/web/index.php?r=site/test&lan=pl&zestaw='.''.$zestaw);
        exit;
    }
    else {
        $RanEn = $blad;
        $_SESSION['RanEn'] = $RanEn;
        $_SESSION['counter'] = 0;
        $tmp[0] = NULL;
        $blad = $tmp;
        $_SESSION['blad'] = $blad;
        $_SESSION['cunt'] = 0;
        header('Location: http://localhost/yii-advanced/frontend/web/index.php?r=site/test&lan=eng&zestaw='.''.$zestaw);
        exit;
    }
}


?>
