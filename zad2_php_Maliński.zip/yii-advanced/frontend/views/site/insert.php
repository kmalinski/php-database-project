<?php
use yii\helpers\Html;
use yii\db\Query;
use yii\db\QueryBuilder;
$tmp = $_SESSION['tab'];
$temp = $tmp[1];
$nazwa = $temp['odp'];

$temp = $tmp[2];
$zestaw = $temp['odp'];

 echo $nazwa;
 echo '<br>';
 echo $zestaw;

 if(!Yii::$app->user->isGuest){
     Yii::$app->db->createCommand()
         ->insert('zestaw', [
             'konto_id' => Yii::$app->user->id,
             'nazwa' => $nazwa,
             'zestaw' => $zestaw,
         ])->execute();

}
