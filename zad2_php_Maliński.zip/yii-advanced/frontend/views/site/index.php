<?php

/* @var $this yii\web\View */
use yii\helpers\Html;
 session_unset();
$this->title = 'System nauki slowek';
?>
<div class="site-index">

    <div class="jumbotron">
    <h1>Wybor kategorii</h1>
    </div>



<div class="site-index" align="center">
        <a class="btn btn-lg btn-primary" href="http://localhost/yii-advanced/frontend/web/index.php?r=site/food">Food</a>
        <a class="btn btn-lg btn-primary" href="http://localhost/yii-advanced/frontend/web/index.php?r=site/animals">Animals</a>
        <a class="btn btn-lg btn-primary" href="http://localhost/yii-advanced/frontend/web/index.php?r=site/vehicles">Vehicles</a>
</div>


    </div>
<div class="site-index" align="center">
<?php if(!Yii::$app->user->isGuest) {
    echo '<br>';
    echo '<a class="btn btn-lg btn-success" href="http://localhost/yii-advanced/frontend/web/index.php?r=site/twojezestawy">Twoje zestawy</a>';
    echo '<a class="btn btn-lg btn-success" href="http://localhost/yii-advanced/frontend/web/index.php?r=site/wyniki">Twoje wyniki</a>';

    $rola = (new \yii\db\Query())
        ->select('rola_id')
        ->from('konto')
        ->where(['id' => Yii::$app->user->id])
        ->all();
    $tmp = ($rola[0]);
    if($tmp['rola_id'] == 1){
        echo '<br>';
        echo '<br>';
        echo '<a class="btn btn-lg btn-warning" href="http://localhost/yii-advanced/backend/web/index.php">Backend</a>';
    }
} ?>
</div>
