<?php
use yii\helpers\Html;
$eng = 'eng';
$pl  ='pl';
$this->title = 'tryb nauki';


$id = $_GET['zestaw'];

if(isset($_GET['wlasny'])) {
    $zestaw = (new \yii\db\Query())
        ->select('zestaw')
        ->from('zestawdodaj')
        ->where(['id' => $id])
        ->all();

    $zestaw_str = implode(" ", $zestaw[0]);
    $str = str_replace(";", " ", $zestaw_str);
    $str = str_replace("\r\n", " ", $zestaw_str);
    $tab = explode(" ", $str);
    $n = count($tab);
    $i = 0;

    while ($i != $n) {
        $temp = $tab[$i];
        $y = explode(";", $temp);
        $final_tab_eng[$i] = $y[0];
        if (($tmp = strstr($temp, ';')) !== false) {
            $x = substr($tmp, 1);
            $final_tab_pl[$i] = $x;
        }
        $i++;
    }


    $randEn = $final_tab_eng;
    $randPl = $final_tab_pl;
    shuffle($randEn);
    shuffle($randPl);
//print_r($randEn);
    $_SESSION['RanEn'] = $randEn;
    $_SESSION['RanPl'] = $randPl;
    $_SESSION['counter'] = 0;
    $_SESSION['finEn'] = $final_tab_eng;
    $_SESSION['finPl'] = $final_tab_pl;
    $_SESSION['j'] = 0;
    for ($i = 0; $i < count($final_tab_pl); $i++) {
        $odp[$i] = 0;
        // $blad[$i] = -1;
        $answer[$i] = '';
    }
//$_SESSION['blad'] = $blad;
    $_SESSION['odp'] = $odp;
    $_SESSION['answer'] = $answer;
    $_SESSION['cunt'] = 0;
}
else {
    $zestaw = (new \yii\db\Query())
        ->select('zestaw')
        ->from('zestaw')
        ->where(['id' => $id])
        ->all();

    $zestaw_str = implode(" ", $zestaw[0]);
    $str = str_replace(";", " ", $zestaw_str);
    $str = str_replace("\r\n", " ", $zestaw_str);
    $tab = explode(" ", $str);
    $n = count($tab);
    $i = 0;

    while ($i != $n) {
        $temp = $tab[$i];
        $y = explode(";", $temp);
        $final_tab_eng[$i] = $y[0];
        if (($tmp = strstr($temp, ';')) !== false) {
            $x = substr($tmp, 1);
            $final_tab_pl[$i] = $x;
        }
        $i++;
    }


    $randEn = $final_tab_eng;
    $randPl = $final_tab_pl;
    shuffle($randEn);
    shuffle($randPl);
//print_r($randEn);
    $_SESSION['RanEn'] = $randEn;
    $_SESSION['RanPl'] = $randPl;
    $_SESSION['counter'] = 0;
    $_SESSION['finEn'] = $final_tab_eng;
    $_SESSION['finPl'] = $final_tab_pl;
    $_SESSION['j'] = 0;
    for ($i = 0; $i < count($final_tab_pl); $i++) {
        $odp[$i] = 0;
        // $blad[$i] = -1;
        $answer[$i] = '';
    }
//$_SESSION['blad'] = $blad;
    $_SESSION['odp'] = $odp;
    $_SESSION['answer'] = $answer;
    $_SESSION['cunt'] = 0;
}
?>

<div class="jumbotron">
    <h1>Tryb Sprawdzania Wiedzy</h1>
</div>

<div class="jumbotron">
    <a class="btn btn-lg btn-default" href="http://localhost/yii-advanced/frontend/web/index.php?r=site/odp&zestaw=<?php echo $id; ?>&lan=<?php echo $eng ?>">ang-pol </a>

    <a class="btn btn-lg btn-default" href="http://localhost/yii-advanced/frontend/web/index.php?r=site/odp&zestaw=<?php echo $id; ?>&lan=<?php echo $pl ?>"">pol-ang </a>
</div>
