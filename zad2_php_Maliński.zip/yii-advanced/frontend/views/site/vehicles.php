<?php

/* @var $this yii\web\View */
use yii\helpers\Html;

$this->title = 'Vehicles';
?>
<div class="jumbotron">
    <h1>Vehicles</h1>

    <p align="center"><h2>Wybor podkategorii</h2></p>
</div>

<div class="row">

    <div align="center">
        <p><h1>Airplanes</h1></p>
        <a href="http://localhost/yii-advanced/frontend/web/index.php?r=site/airplane">
            <img src="images/airplane.jpg" alt="airplane">
        </a>
    </div>
    <div align="center">
        <p><h1>Vehicles</h1></p>
        <a href="http://localhost/yii-advanced/frontend/web/index.php?r=site/vehi">
            <img src="images/vehicle.jpg" alt="vehicle">
        </a>
    </div>

    <div align="center">
        <p><h1>Water Transport</h1></p>
        <a href="http://localhost/yii-advanced/frontend/web/index.php?r=site/water">
            <img src="images/boat.jpg" alt="boat">
        </a>
    </div>
</div>