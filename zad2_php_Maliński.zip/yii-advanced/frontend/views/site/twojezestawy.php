<!DOCTYPE html>
<html>
<head>
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
        th,td {
            padding: 15px;
        }
    </style>
    <div class="jumbotron">
        <h1>Twoje Zestawy:</h1>
    </div>
</head>
<body>
<?php
$_SESSION['zestawCount'] = 0;
$tab[0] = NULL;
$_SESSION['tab'] = $tab;
use yii\helpers\Html;
if(!Yii::$app->user->isGuest) {
    $id = \Yii::$app->user->id;
    $this->title = 'Twoje zestawy';
    $space = ':';
    $name = (new \yii\db\Query())
        ->select('username')
        ->from('konto')
        ->where(['id' => $id])
        ->all();

    $zestaw = (new \yii\db\Query())
        ->select('zestaw')
        ->from('zestawdodaj')
        ->where(['username' => $name])
        ->all();
    $xd = 0;
    if ($zestaw == NULL) {
        echo Html::tag('h1', 'Nie masz jeszcze zadnych zestawow', ['class' => 'jumbotron']);
        echo Html::a('Dodaj zestaw', 'http://localhost/yii-advanced/frontend/web/index.php?r=zestawdodaj%2Fcreate', ['class' => 'btn, btn-lg btn-success', 'align' => 'center']);
    } else { ?>
    <div align="center">
<?php        echo Html::a('Dodaj zestaw', 'http://localhost/yii-advanced/frontend/web/index.php?r=zestawdodaj%2Fcreate', ['class' => 'btn, btn-lg btn-warning', 'align' => 'center']);
        echo '<br>';
    echo '<br>';
   ?> </div>    <?php
       // print_r($zestaw);
        $xd = 0;
        while($xd != count($zestaw)) {
            $nr= $xd+1;
            $zestaw_str = implode(" ", $zestaw[$xd]);
            $str = str_replace(";", " ", $zestaw_str);
            $str = str_replace("\r\n", " ", $zestaw_str);
            $tab = explode(" ", $str);
            $n = count($tab);
            $i = 0;

            while ($i != $n) {


                $temp = $tab[$i];
                $y = explode(";", $temp);
                $final_tab_eng[$i] = $y[0];
                if (($tmp = strstr($temp, ';')) !== false) {
                    $x = substr($tmp, 1);
                    $final_tab_pl[$i] = $x;
                }
                $i++;
            }
?>
<div align="center">
    <table>
        <tr>
            <th>Angielski </th>
            <th> Polski</th>
        </tr>
        <?php
            $nazwa = (new \yii\db\Query())
                ->select('nazwa')
                ->from('zestawdodaj')
                ->where(['username' => $name])
                ->all();
//print_r($nazwa);
$tt = $nazwa[$xd];




            //echo Html::tag('b', 'Zestaw nr'. ' ' . $nr . ''. $space, ['class' => 'row']);
            for ($i = 0; $i < count($final_tab_eng); $i++) {
                $napis = $final_tab_eng[$i] . '-' . $final_tab_pl[$i];
                echo Html::tag('tr');
                echo Html::tag('td', $final_tab_eng[$i]);
                echo Html::tag('td', $final_tab_pl[$i]);

                echo Html::tag('/tr');
            }



            $xd++;
            $tmpp[0] = NULL;
            $final_tab_eng = $tmpp;
            $final_tab_pl  =$tmpp;
            $numer= (new \yii\db\Query())
                ->select('id')
                ->from('zestawdodaj')
                ->where(['username' => $name])
                ->all();

            // print_r($numer);
            $t = $numer[$xd-1];
            //print_r($t);
            echo Html::a('Nauka z zestawem' . ' ' . $tt['nazwa'], 'http://localhost/yii-advanced/frontend/web/index.php?r=site/wybor&zestaw='.''.$t['id'].''.'&wlasny=true',['class' => 'btn btn-lg btn-success']);
            echo '<br>';
            echo Html::a('Edytuj zestaw' . ' ' . $tt['nazwa'], 'http://localhost/yii-advanced/frontend/web/index.php?r=zestawdodaj%2Fupdate&id='.''.$t['id'],['class' => 'btn btn-lg btn-primary']);
            echo '<br>';
            echo Html::a('Usuń zestaw' . ' ' . $tt['nazwa'], 'http://localhost/yii-advanced/frontend/web/index.php?r=site/usun&zestaw='.''.$t['id'],['class' => 'btn btn-lg btn-danger']);
            echo '<br>';
            echo '<br>';
        }
        ?>
        </table>
        </div>

        <?php
    }
    }
else{
    echo Html::tag('h1', 'Musisz sie zalogowac aby miec dostep do swoich zestawow', ['class' => 'jumbotron']);
    echo Html::a('OK','http://localhost/yii-advanced/frontend/web/index.php?', ['class' => 'btn, btn-lg btn-success','align'=>'center'] );
} ?>
</body>
</html>
