<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$i = $_SESSION['counter'];
$En = $_SESSION['finEn'];
$Pl = $_SESSION['finPl'];
$wynik = $_SESSION['odp'];

$RanEn = $_SESSION['RanEn'];
$RanPl = $_SESSION['RanPl'];
$lan = $_SESSION['lang'];
$answer = $_SESSION['answer'];
$test = 'dziala';
$zestaw = $_GET['zestaw'];
//echo $i;
//echo '<br>';
//echo count($RanEn);


if ($lan == 'eng') {
    if ($i != count($RanEn)) {
        $form = ActiveForm::begin(); ?>
        <?= Html::tag('h1', $RanEn[$i], ['class' => 'jumbotron']); ?>
        <?= $form->field($model, 'odp'); ?>
        <?= Html::submitButton('Submit', ['class' => 'btn btn-success']); ?>

        <?php ActiveForm::end(); ?>
        <?php
        $tmp = $_SESSION['pytanie'];
        $tmp[$i] = $RanEn[$i];
        $_SESSION['pytanie'] = $tmp;
    }


    if (isset($_POST["OdpForm"])) {
        $te = $_POST["OdpForm"];
        print_r($te);
        $tes = array_rand($te, 1);
        echo $te[$tes];

    if($i == 1 || $i == 0) {
        for ($j = 0; $j < count($RanEn); $j++) {
            if ($i == 0) {
                if ($RanEn[0] == $En[$j]) {
                    $x = $j;

                }
            } elseif ($RanEn[$i - 1] == $En[$j]) {
                $x = $j;
            }
        }

        if ($te[$tes] == $Pl[$x]) {

            //echo 'ok';
            $answer[$i - 1] = $te[$tes];
            $_SESSION['answer'] = $answer;
            $wynik[$i] = 1;
            $_SESSION['odp'] = $wynik;
            $i++;
            $_SESSION['counter'] = $i;
        } else {
            $answer[$i - 1] = $te[$tes];
            $_SESSION['answer'] = $answer;
            $i++;
            $_SESSION['counter'] = $i;
            //echo 'nie ok';
        }
    }
    else{
        for ($j = 0; $j < count($RanPl); $j++) {
            if ($i == 0) {
                if ($RanPl[0] == $Pl[$j]) {
                    $x = $j;

                }
            } elseif ($RanPl[$i - 1] == $Pl[$j]) {
                $x = $j;
            }
        }
        if (isset($te)) {
            if ($te[$tes] == $En[$x]) {

                //echo 'ok';
                $answer[$i-1] = $te[$tes];
                $_SESSION['answer'] = $answer;
                $wynik[$i] = 1;
                $_SESSION['odp'] = $wynik;
                $i++;
                $_SESSION['counter'] = $i;
            } else {
                $answer[$i-1] = $te[$tes];
                $_SESSION['answer'] = $answer;
                $i++;
                $_SESSION['counter'] = $i;
                //echo 'nie ok';
            }
        }
    }
    } else {

        $i++;
        $_SESSION['counter'] = $i;
    }
    $_SESSION['lang'] = 'pl';
}


elseif ($lan == 'pl') {
    if ($i != count($RanPl)) {
        $form = ActiveForm::begin(); ?>
        <?= Html::tag('h1', $RanPl[$i], ['class' => 'jumbotron']); ?>
        <?= $form->field($model, 'odp'); ?>
        <?= Html::submitButton('Submit', ['class' => 'btn btn-success']); ?>

        <?php ActiveForm::end(); ?>

        <?php
        $tmp = $_SESSION['pytanie'];
        $tmp[$i] = $RanPl[$i];
        $_SESSION['pytanie'] = $tmp;
    }

    if (isset($_POST["OdpForm"])) {
        $te = $_POST["OdpForm"];
        print_r($te);
        $tes = array_rand($te, 1);
        echo $te[$tes];

        if ($i == 1 || $i == 0) {
            for ($j = 0; $j < count($RanPl); $j++) {
                if ($i == 0) {
                    if ($RanPl[0] == $Pl[$j]) {
                        $x = $j;

                    }
                } elseif ($RanPl[$i - 1] == $Pl[$j]) {
                    $x = $j;
                }
            }
            if (isset($te)) {
                if ($te[$tes] == $En[$x]) {

                    echo 'ok';
                    $answer[$i - 1] = $te[$tes];
                    $_SESSION['answer'] = $answer;
                    $wynik[$i] = 1;
                    $_SESSION['odp'] = $wynik;
                    $i++;
                    $_SESSION['counter'] = $i;
                } else {
                    $answer[$i - 1] = $te[$tes];
                    $_SESSION['answer'] = $answer;
                    $i++;
                    $_SESSION['counter'] = $i;
                    echo 'nie ok';
                }
            }
        }
        else{
            for ($j = 0; $j < count($RanEn); $j++) {
                if ($i == 0) {
                    if ($RanEn[0] == $En[$j]) {
                        $x = $j;

                    }
                } elseif ($RanEn[$i - 1] == $En[$j]) {
                    $x = $j;
                }
            }

            if ($te[$tes] == $Pl[$x]) {

                echo 'ok';
                $answer[$i - 1] = $te[$tes];
                $_SESSION['answer'] = $answer;
                $wynik[$i] = 1;
                $_SESSION['odp'] = $wynik;
                $i++;
                $_SESSION['counter'] = $i;
            } else {
                $answer[$i - 1] = $te[$tes];
                $_SESSION['answer'] = $answer;
                $i++;
                $_SESSION['counter'] = $i;
                echo 'nie ok';
            }
        }
    }else {

        $i++;
        $_SESSION['counter'] = $i;
    }
    $_SESSION['lang'] = 'eng';
}

if($i == count($RanEn)+1) {
    if($lan=='pl') {
        header('Location: http://localhost/yii-advanced/frontend/web/index.php?r=site/wynik&lan=pl&zestaw='. ''.$zestaw);
        exit;
    }
    else {
        header('Location: http://localhost/yii-advanced/frontend/web/index.php?r=site/wynik&lan=eng&zestaw='.''.$zestaw);
        exit;
    }
}

?>
