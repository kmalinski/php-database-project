<?php
use yii\helpers\Html;
use yii\widgets\ActiveForm;
$this->title="Dodaj zestaw";

$tab = $_SESSION['tab'];
 if($_SESSION['zestawCount']== 0){
?>
<?php $form = ActiveForm::begin(); ?>
<?= Html::tag('h1', 'Nazwa Zestawu', ['class' => 'jumbotron']); ?>
<?= $form->field($model, 'odp'); ?>

<?= Html::submitButton('Submit', ['class' => 'btn btn-success']); ?>

<?php ActiveForm::end(); ?>
     <?php


 }
if (isset($_POST["OdpForm"])) {
    $_SESSION['zestawName'] = $_POST["OdpForm"];
}
 if($_SESSION['zestawCount'] == 1){
 $form = ActiveForm::begin(); ?>
<?= Html::tag('h1', 'Tu wklej zestaw w formie ang;pl', ['class' => 'jumbotron']); ?>
<?= $form->field($model, 'odp'); ?>

<?= Html::submitButton('Submit', ['class' => 'btn btn-success']); ?>

<?php ActiveForm::end();

 }

if (isset($_POST["OdpForm"])) {
    $tab[$_SESSION['zestawCount']] = $_POST["OdpForm"];
    $_SESSION['tab']= $tab;
}
$_SESSION['zestawCount']++;
echo $_SESSION['zestawCount'];
if($_SESSION['zestawCount'] == 3){
    header('Location: http://localhost/yii-advanced/frontend/web/index.php?r=site/insert');
    exit;
}

