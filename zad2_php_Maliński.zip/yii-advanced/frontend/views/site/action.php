<?php



$En = $_SESSION['finEn'];
$Pl = $_SESSION['finPl'];
$i = $_SESSION['counter'];
$RanEn = $_SESSION['RanEn'];
$RanPl = $_SESSION['RanPl'];
$lan = $_GET['lan'];
$answer = $_SESSION['odp'];

if($lan == 'eng') {
}
?>