<?php

$this->title = 'alg1';
    echo $_GET['zestaw'];
    ?>