<?php

/* @var $this yii\web\View */
use yii\helpers\Html;

$this->title = 'Food';
?>
        <div class="jumbotron">
                 <h1>Food</h1>

            <p align="center"> <h2>Wybor podkategorii:</h2></p>
        </div>

    <div class="row">

          <div align="center">
        <p><h1>Fruit</h1></p>
              <a href="http://localhost/yii-advanced/frontend/web/index.php?r=site/fruit">
              <img src="images/fruit.jpg" alt="fruit">
              </a>
    </div>
        <div align="center">
            <p><h1>Vegetables</h1></p>
            <a href="http://localhost/yii-advanced/frontend/web/index.php?r=site/vegetables">
                <img src="images/vegetables.jpg" alt="vegetables">
            </a>
        </div>

        <div align="center">
            <p><h1>Meat</h1></p>
            <a href="http://localhost/yii-advanced/frontend/web/index.php?r=site/meat">
                <img src="images/meat.jpg" alt="meat">
            </a>
    </div>
    </div>
