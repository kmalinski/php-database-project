<!DOCTYPE html>
<html>
<head>
<style>
    table, th, td {
        border: 1px solid black;
        border-collapse: collapse;
    }
    th,td {
        padding: 15px;
    }
</style>
</head>
<body>



<?php
use yii\helpers\Html;
$eng = 'eng';
$pl  ='pl';
$this->title = 'tryb nauki';


$id = $_GET['zestaw'];

if(isset($_GET['wlasny'])){
    $zestaw = (new \yii\db\Query())
        ->select('zestaw')
        ->from('zestawdodaj')
        ->where(['id' => $id])
        ->all();

    $zestaw_str = implode(" ",$zestaw[0]);
    $str =  str_replace(";"," ",$zestaw_str);
    $str =  str_replace("\r\n"," ",$zestaw_str);
    $tab = explode(" ",$str);
    $n = count($tab);
    $i = 0;

    while($i != $n){
        $temp =  $tab[$i];
        $y = explode(";", $temp);
        $final_tab_eng[$i] = $y[0];
        if (($tmp = strstr($temp, ';')) !== false) {
            $x = substr($tmp, 1);
            $final_tab_pl[$i] = $x;
        }
        $i++;
    }
    echo Html::tag('h1', 'Wybrany zestaw');
    ?>
    <div>
        <table>
            <tr>
                <th>Angielski </th>
                <th> Polski</th>
            </tr>
            <?php

            for ($i = 0; $i < count($final_tab_eng); $i++) {
                echo Html::tag('tr');
                echo Html::tag('td', $final_tab_eng[$i]);
                echo Html::tag('td', $final_tab_pl[$i]);
                //$napis = $final_tab_eng[$i] . '-' . $final_tab_pl[$i];
                //echo  Html::tag('p', $napis, ['class' =>'row']);
                echo Html::tag('/tr');
            }
            ?>
        </table>
    </div>

    <?php
    $randEn = $final_tab_eng;
    $randPl = $final_tab_pl;
    shuffle($randEn);
    shuffle($randPl);
//print_r($randEn);
    $_SESSION['RanEn'] = $randEn;
    $_SESSION['RanPl'] = $randPl;
    $_SESSION['counter'] = 0;
    $_SESSION['finEn'] = $final_tab_eng;
    $_SESSION['finPl'] = $final_tab_pl;
    $_SESSION['j'] = 0;
    $blad[0] = 'a';
    for($i=0; $i < count($final_tab_pl); $i++) {
        $odp[$i] = 0;
        //$blad[$i] = $i;
        $answer[$i] = '';
    }
    $_SESSION['blad'] = $blad;
    $_SESSION['odp'] = $odp;
    $_SESSION['answer'] = $answer;
    $_SESSION['tester'] = 0;
    $_SESSION['cunt'] = 0;
    $_SESSION['wynCounter'] = 0;
    $_SESSION['proby'] = 0;
}
else {
    $zestaw = (new \yii\db\Query())
        ->select('zestaw')
        ->from('zestaw')
        ->where(['id' => $id])
        ->all();

    $zestaw_str = implode(" ", $zestaw[0]);
    $str = str_replace(";", " ", $zestaw_str);
    $str = str_replace("\r\n", " ", $zestaw_str);
    $tab = explode(" ", $str);
    $n = count($tab);
    $i = 0;

    while ($i != $n) {
        $temp = $tab[$i];
        $y = explode(";", $temp);
        $final_tab_eng[$i] = $y[0];
        if (($tmp = strstr($temp, ';')) !== false) {
            $x = substr($tmp, 1);
            $final_tab_pl[$i] = $x;
        }
        $i++;
    }
    echo Html::tag('h1', 'Wybrany zestaw');
    ?>
    <div>
        <table>
            <tr>
                <th>Angielski </th>
                <th> Polski</th>
            </tr>
            <?php

            for ($i = 0; $i < count($final_tab_eng); $i++) {
                echo Html::tag('tr');
                echo Html::tag('td', $final_tab_eng[$i]);
                echo Html::tag('td', $final_tab_pl[$i]);

                echo Html::tag('/tr');
            }
            ?>
        </table>
    </div>

<?php


    $randEn = $final_tab_eng;
    $randPl = $final_tab_pl;
    shuffle($randEn);
    shuffle($randPl);
//print_r($randEn);
    $_SESSION['RanEn'] = $randEn;
    $_SESSION['RanPl'] = $randPl;
    $_SESSION['counter'] = 0;
    $_SESSION['finEn'] = $final_tab_eng;
    $_SESSION['finPl'] = $final_tab_pl;
    $_SESSION['j'] = 0;
    $blad[0] = 'a';
    for ($i = 0; $i < count($final_tab_pl); $i++) {
        $odp[$i] = 0;
        //$blad[$i] = $i;
        $answer[$i] = '';
    }
    $_SESSION['blad'] = $blad;
    $_SESSION['odp'] = $odp;
    $_SESSION['answer'] = $answer;
    $_SESSION['tester'] = 0;
    $_SESSION['cunt'] = 0;
    $_SESSION['wynCounter'] = 0;
    $_SESSION['proby'] = 0;
}
?>


    <div class="jumbotron">
        <h1>Tryb Nauki</h1>
    </div>

    <div class="jumbotron">
        <a class="btn btn-lg btn-default" href="http://localhost/yii-advanced/frontend/web/index.php?r=site/algorytm&zestaw=<?php echo $id; ?>&lan=<?php echo $eng ?>">ang-pol </a>

        <a class="btn btn-lg btn-default" href="http://localhost/yii-advanced/frontend/web/index.php?r=site/algorytm&zestaw=<?php echo $id; ?>&lan=<?php echo $pl ?>"">pol-ang </a>
    </div>

</body>
</html>