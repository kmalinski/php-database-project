<?php
use yii\helpers\Html;
use yii\db\QueryBuilder;
use yii\db\Query;

$wynik = $_SESSION['odp'];
$j=  $_SESSION['blad'];
$RanEn = $_SESSION['RanEn'];
$RanPl = $_SESSION['RanPl'];
$lan = $_GET['lan'];
//print_r($j);
    $cunt = 0;
    $pytanie = $_SESSION['pytanie'];
$odp = $_SESSION['answer'];
$zestaw = $_GET['zestaw'];
//print_r($odp);
    for($i = 0; $i<count($wynik); $i++){
        if($wynik[$i] == 1) {
            $cunt++;
        }
    }
    $fin =count($wynik) -1;
    $wyn = $cunt/$fin;
$wyn2 = $wyn * 10;
$wyn2 = $wyn2.''.'%';


    if(!Yii::$app->user->isGuest){

            echo Html::tag('h2', 'Wynik zostal zapisany');



         Yii::$app->db->createCommand()
             ->insert('wynik', [
                     'konto_id' => Yii::$app->user->id,
                     'zestaw_id' => $zestaw,
                 'wynik' => $wyn,
             ])->execute();
 }

    ?>

    <div class="jumbotron">
        <h1>Twoj wynik to:</h1>
        <h2><?php echo $wyn2 ?></h2>
        <a class="btn btn-lg btn-success" href="http://localhost/yii-advanced/frontend/web/index.php">OK</a>
    </div>
<?php
if('lan' == 'pl') {
    echo Html::tag('h1', 'Twoje odpowiedzi:');
    for ($i = 0; $i < count($odp); $i++) {
        echo Html::tag('h1',$pytanie[$i] . ' : ' . $odp[$i], ['class' => 'row']);
    }
}
else {
    echo Html::tag('h1', 'Twoje odpowiedzi:');
    for ($i = 0; $i < count($odp); $i++) {
        echo Html::tag('h1',$pytanie[$i]. ' : ' . $odp[$i], ['class' => 'row']);
    }
}
?>



  <?php  session_unset();   ?>
