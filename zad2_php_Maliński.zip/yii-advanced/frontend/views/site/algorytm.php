<?php
use yii\helpers\Html;
$this->title = 'tryb nauki';

$lan = $_GET['lan'];
$id = $_GET['zestaw'];
$_SESSION['lang'] = 'eng';
$pytanie[0] = NULL;
$_SESSION['pytanie'] = $pytanie;
?>





<div class="jumbotron">
    <h1>Wybor algorytmu</h1>
</div>

<div class="jumbotron">
    <a class="btn btn-lg btn-default" href="http://localhost/yii-advanced/frontend/web/index.php?r=site/odp&zestaw=<?php echo $id; ?>&lan=<?php echo $lan ?>">Algorytm 1 </a>

    <a class="btn btn-lg btn-default" href="http://localhost/yii-advanced/frontend/web/index.php?r=site/odpp&zestaw=<?php echo $id; ?>&lan=<?php echo $lan ?>"">Algorytm 2 </a>
    <?php if($lan == 'eng'){echo Html::a('Algorytm 3', "http://localhost/yii-advanced/frontend/web/index.php?r=site/algg&zestaw=".''.$id.'&lan='.''.$lan, ['class' =>  'btn btn-lg btn-default']);} ?>
</div>
