<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model frontend\models\ZestawUzytkownika */

$this->title = 'Create Zestaw Uzytkownika';
$this->params['breadcrumbs'][] = ['label' => 'Zestaw Uzytkownikas', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="zestaw-uzytkownika-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
